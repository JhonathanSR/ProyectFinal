package com.example.localizaapp

class Usuario {

}
